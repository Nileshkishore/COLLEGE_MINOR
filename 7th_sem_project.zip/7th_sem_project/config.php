<?php

$conn = mysqli_connect('localhost','root','','user_db_4') or die('connection failed');

?>